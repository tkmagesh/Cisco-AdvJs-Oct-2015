  $(function(){
        var calculator = new SalaryCalculator();
        var calculatorView = new SalaryCalculatorView(calculator);
        calculatorView.init();
    });