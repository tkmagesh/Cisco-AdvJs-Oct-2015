Object.prototype.toInt = function(){
        return parseInt(this,10);
    };